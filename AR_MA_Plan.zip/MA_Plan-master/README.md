# MA_Plan
MA thesis plan
